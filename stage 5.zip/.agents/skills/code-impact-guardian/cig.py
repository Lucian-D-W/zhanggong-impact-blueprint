#!/usr/bin/env python3
import argparse
import json
import pathlib
import shutil
import subprocess
import sys


SKILL_DIR = pathlib.Path(__file__).resolve().parent
SCRIPTS_DIR = SKILL_DIR / "scripts"
if str(SCRIPTS_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPTS_DIR))

import after_edit_update  # noqa: E402
import build_graph  # noqa: E402
import generate_report  # noqa: E402
import list_seeds  # noqa: E402
from adapters import SQL_POSTGRES_ADAPTER, configured_supplemental_adapters, detect_language_adapter, detect_project_profile_name, detect_supplemental_adapters  # noqa: E402
from doc_sources import doc_source_doctor_status  # noqa: E402
from profiles import AUTO_PROFILE, PROFILE_PRESETS, apply_profile_preset, detect_project_profile, package_json_data, profile_coverage_adapter, profile_test_command  # noqa: E402


DEFAULT_CONFIG = {
    "project_root": ".",
    "primary_adapter": "auto",
    "supplemental_adapters": [],
    "language_adapter": "auto",
    "project_profile": "auto",
    "rule_adapter": "markdown",
    "doc_source_adapter": "local_markdown",
    "doc_cache": {
        "enabled": True,
        "dir": ".ai/codegraph/doc-cache",
    },
    "graph": {
        "db_path": ".ai/codegraph/codegraph.db",
        "report_dir": ".ai/codegraph/reports",
        "build_log_path": ".ai/codegraph/build.log",
        "test_results_path": ".ai/codegraph/test-results.json",
    },
    "rules": {"globs": ["docs/rules/*.md"]},
    "python": {
        "source_globs": ["src/*.py", "src/**/*.py"],
        "test_globs": ["tests/*.py", "tests/**/*.py"],
        "test_command": ["python", "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"],
        "coverage_adapter": "coveragepy",
    },
    "tsjs": {
        "source_globs": ["src/*.js", "src/**/*.js", "src/*.ts", "src/**/*.ts", "src/*.jsx", "src/**/*.jsx", "src/*.tsx", "src/**/*.tsx"],
        "test_globs": ["tests/*.js", "tests/**/*.js", "tests/*.ts", "tests/**/*.ts", "tests/*.jsx", "tests/**/*.jsx", "tests/*.tsx", "tests/**/*.tsx"],
        "test_command": ["node", "--test"],
        "coverage_adapter": "v8_family",
    },
    "generic": {
        "source_globs": ["src/*", "src/**/*"],
        "test_command": [],
        "coverage_adapter": "unavailable",
    },
    "rust_lite": {
        "parser_backend": "rust_lite_placeholder",
        "enabled": False,
    },
    "sql_postgres": {
        "enabled": False,
        "source_globs": [
            "db/*.sql",
            "db/**/*.sql",
            "sql/*.sql",
            "sql/**/*.sql",
            "migrations/*.sql",
            "migrations/**/*.sql",
            "supabase/migrations/*.sql",
            "supabase/migrations/**/*.sql"
        ],
        "test_globs": [
            "tests/sql/*.sql",
            "tests/sql/**/*.sql",
            "db/tests/*.sql",
            "db/tests/**/*.sql"
        ],
        "test_command": [
            "python",
            "-c",
            "import pathlib; roots=[pathlib.Path('tests/sql'), pathlib.Path('db/tests')]; files=[]; [files.extend(sorted(root.rglob('*.sql'))) for root in roots if root.exists()]; assert files, 'no SQL test files found'; text='\\n'.join(p.read_text(encoding='utf-8') for p in files).lower(); assert any(token in text for token in ('select ', 'call ', 'perform ')), 'no SQL invocation statements found in SQL tests'"
        ],
        "coverage_adapter": "unavailable",
        "parser_backend": "sql_postgres_lite",
    },
    "impact": {"max_depth": 3},
}


DEFAULT_SCHEMA_TEXT = """PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS repo_meta (
  meta_key TEXT PRIMARY KEY,
  meta_value TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS nodes (
  node_id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK(kind IN ('file', 'function', 'test', 'rule')),
  name TEXT NOT NULL,
  path TEXT NOT NULL,
  symbol TEXT,
  start_line INTEGER,
  end_line INTEGER,
  attrs_json TEXT NOT NULL DEFAULT '{}',
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS evidence (
  evidence_id TEXT PRIMARY KEY,
  repo_source_id TEXT NOT NULL,
  git_sha TEXT NOT NULL,
  file_path TEXT NOT NULL,
  start_line INTEGER,
  end_line INTEGER,
  diff_ref TEXT,
  blame_ref TEXT,
  permalink TEXT,
  stable_link TEXT,
  extractor TEXT NOT NULL,
  confidence REAL NOT NULL DEFAULT 1.0,
  attrs_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS edges (
  edge_id INTEGER PRIMARY KEY AUTOINCREMENT,
  src_id TEXT NOT NULL REFERENCES nodes(node_id) ON DELETE CASCADE,
  edge_type TEXT NOT NULL CHECK(edge_type IN ('DEFINES', 'CALLS', 'IMPORTS', 'COVERS', 'GOVERNS')),
  dst_id TEXT NOT NULL REFERENCES nodes(node_id) ON DELETE CASCADE,
  is_direct INTEGER NOT NULL DEFAULT 1 CHECK(is_direct IN (0, 1)),
  evidence_id TEXT REFERENCES evidence(evidence_id) ON DELETE SET NULL,
  confidence REAL NOT NULL DEFAULT 1.0,
  attrs_json TEXT NOT NULL DEFAULT '{}',
  UNIQUE(src_id, edge_type, dst_id, is_direct)
);

CREATE TABLE IF NOT EXISTS rule_documents (
  rule_node_id TEXT PRIMARY KEY REFERENCES nodes(node_id) ON DELETE CASCADE,
  markdown_path TEXT NOT NULL,
  frontmatter_json TEXT NOT NULL DEFAULT '{}',
  body_markdown TEXT NOT NULL,
  updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS impact_reports (
  report_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  seed_node_id TEXT NOT NULL,
  git_sha TEXT NOT NULL,
  report_path TEXT NOT NULL,
  attrs_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS test_runs (
  run_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  command_json TEXT NOT NULL,
  status TEXT NOT NULL,
  exit_code INTEGER,
  output_path TEXT,
  coverage_path TEXT,
  coverage_status TEXT NOT NULL,
  coverage_reason TEXT,
  attrs_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS coverage_observations (
  observation_id INTEGER PRIMARY KEY AUTOINCREMENT,
  run_id TEXT NOT NULL REFERENCES test_runs(run_id) ON DELETE CASCADE,
  test_node_id TEXT REFERENCES nodes(node_id) ON DELETE SET NULL,
  target_node_id TEXT REFERENCES nodes(node_id) ON DELETE SET NULL,
  file_path TEXT NOT NULL,
  line_no INTEGER,
  summary_json TEXT NOT NULL DEFAULT '{}',
  raw_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS task_runs (
  task_run_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  seed_node_id TEXT NOT NULL,
  command_name TEXT NOT NULL,
  detected_adapter TEXT NOT NULL,
  report_path TEXT,
  status TEXT NOT NULL,
  attrs_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS edit_rounds (
  edit_round_id TEXT PRIMARY KEY,
  task_id TEXT NOT NULL,
  task_run_id TEXT NOT NULL REFERENCES task_runs(task_run_id) ON DELETE CASCADE,
  round_index INTEGER NOT NULL,
  seed_node_id TEXT NOT NULL,
  changed_files_json TEXT NOT NULL DEFAULT '[]',
  summary_json TEXT NOT NULL DEFAULT '{}',
  created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS file_diffs (
  file_diff_id INTEGER PRIMARY KEY AUTOINCREMENT,
  edit_round_id TEXT NOT NULL REFERENCES edit_rounds(edit_round_id) ON DELETE CASCADE,
  file_path TEXT NOT NULL,
  diff_kind TEXT NOT NULL,
  before_hash TEXT,
  after_hash TEXT,
  summary_json TEXT NOT NULL DEFAULT '{}'
);

CREATE TABLE IF NOT EXISTS symbol_diffs (
  symbol_diff_id INTEGER PRIMARY KEY AUTOINCREMENT,
  edit_round_id TEXT NOT NULL REFERENCES edit_rounds(edit_round_id) ON DELETE CASCADE,
  file_path TEXT NOT NULL,
  symbol_kind TEXT NOT NULL,
  diff_kind TEXT NOT NULL,
  before_symbol TEXT,
  after_symbol TEXT,
  summary_json TEXT NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_nodes_kind ON nodes(kind);
CREATE INDEX IF NOT EXISTS idx_nodes_path ON nodes(path);
CREATE INDEX IF NOT EXISTS idx_edges_src ON edges(src_id);
CREATE INDEX IF NOT EXISTS idx_edges_dst ON edges(dst_id);
CREATE INDEX IF NOT EXISTS idx_edges_type ON edges(edge_type);
CREATE INDEX IF NOT EXISTS idx_evidence_file_path ON evidence(file_path);
CREATE INDEX IF NOT EXISTS idx_test_runs_task ON test_runs(task_id);
CREATE INDEX IF NOT EXISTS idx_task_runs_task ON task_runs(task_id);
CREATE INDEX IF NOT EXISTS idx_edit_rounds_task ON edit_rounds(task_id);
CREATE INDEX IF NOT EXISTS idx_file_diffs_round ON file_diffs(edit_round_id);
CREATE INDEX IF NOT EXISTS idx_symbol_diffs_round ON symbol_diffs(edit_round_id);

INSERT INTO repo_meta(meta_key, meta_value) VALUES
  ('schema_version', '2'),
  ('graph_mode', 'direct-edges-only')
ON CONFLICT(meta_key) DO UPDATE SET meta_value = excluded.meta_value;
"""


def template_root() -> pathlib.Path:
    return SKILL_DIR.parents[2]


def copy_template(source_root: pathlib.Path, destination_root: pathlib.Path) -> None:
    ignore = shutil.ignore_patterns(".git", ".ai", "__pycache__", "*.pyc", "dist", "*.zip")
    if destination_root.exists():
        shutil.rmtree(destination_root)
    shutil.copytree(source_root, destination_root, ignore=ignore)


def init_git_repo(workspace_root: pathlib.Path) -> None:
    subprocess.run(["git", "init"], cwd=workspace_root, check=True, capture_output=True, text=True)
    subprocess.run(["git", "config", "user.name", "Code Impact Guardian Demo"], cwd=workspace_root, check=True)
    subprocess.run(["git", "config", "user.email", "demo@example.invalid"], cwd=workspace_root, check=True)
    subprocess.run(["git", "config", "core.autocrlf", "false"], cwd=workspace_root, check=True)
    subprocess.run(["git", "add", "."], cwd=workspace_root, check=True)
    subprocess.run(["git", "commit", "-m", "Initialize demo workspace"], cwd=workspace_root, check=True, capture_output=True, text=True)


def load_json(path: pathlib.Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def write_json(path: pathlib.Path, payload: dict) -> None:
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def config_path_for(workspace_root: pathlib.Path) -> pathlib.Path:
    return workspace_root / ".code-impact-guardian" / "config.json"


def schema_path_for(workspace_root: pathlib.Path) -> pathlib.Path:
    return workspace_root / ".code-impact-guardian" / "schema.sql"


def default_config_payload() -> dict:
    return json.loads(json.dumps(DEFAULT_CONFIG))


def default_schema_text() -> str:
    source_schema = template_root() / ".code-impact-guardian" / "schema.sql"
    if source_schema.exists():
        return source_schema.read_text(encoding="utf-8")
    return DEFAULT_SCHEMA_TEXT


def normalize_with_adapter(value: str) -> str:
    return value.replace("-", "_")


def init_workspace(
    workspace_root: pathlib.Path,
    *,
    profile: str | None = None,
    project_root: str | None = None,
    with_adapters: list[str] | None = None,
) -> dict:
    codegraph_dir = workspace_root / ".ai" / "codegraph"
    report_dir = codegraph_dir / "reports"
    doc_cache_dir = codegraph_dir / "doc-cache"
    config_dir = workspace_root / ".code-impact-guardian"
    config_dir.mkdir(parents=True, exist_ok=True)
    codegraph_dir.mkdir(parents=True, exist_ok=True)
    report_dir.mkdir(parents=True, exist_ok=True)
    doc_cache_dir.mkdir(parents=True, exist_ok=True)

    config_path = config_path_for(workspace_root)
    schema_path = schema_path_for(workspace_root)
    created: list[str] = []

    config_payload = default_config_payload() if not config_path.exists() else load_json(config_path)
    if project_root:
        config_payload["project_root"] = project_root
    config_payload["primary_adapter"] = config_payload.get("primary_adapter", config_payload.get("language_adapter", "auto"))
    config_payload["language_adapter"] = config_payload["primary_adapter"]
    config_payload["supplemental_adapters"] = list(config_payload.get("supplemental_adapters", []))
    if profile and profile != AUTO_PROFILE:
        config_payload = apply_profile_preset(config_payload, profile)
    elif "project_profile" not in config_payload:
        config_payload["project_profile"] = AUTO_PROFILE

    for adapter_name in with_adapters or []:
        normalized = normalize_with_adapter(adapter_name)
        if normalized not in config_payload["supplemental_adapters"]:
            config_payload["supplemental_adapters"].append(normalized)
        if normalized == SQL_POSTGRES_ADAPTER:
            config_payload.setdefault(SQL_POSTGRES_ADAPTER, {})
            config_payload[SQL_POSTGRES_ADAPTER]["enabled"] = True

    resolved_project_root = (workspace_root / config_payload["project_root"]).resolve()
    active_profile = config_payload.get("project_profile", AUTO_PROFILE)
    if active_profile != AUTO_PROFILE:
        if PROFILE_PRESETS.get(active_profile, {}).get("language_adapter") == "tsjs":
            config_payload["tsjs"]["test_command"] = profile_test_command(active_profile, resolved_project_root, config_payload, "tsjs")
            config_payload["tsjs"]["coverage_adapter"] = profile_coverage_adapter(active_profile, config_payload, "tsjs")

    if not config_path.exists():
        write_json(config_path, config_payload)
        created.append(str(config_path.relative_to(workspace_root)))
    else:
        write_json(config_path, config_payload)
    if not schema_path.exists():
        schema_path.write_text(default_schema_text(), encoding="utf-8")
        created.append(str(schema_path.relative_to(workspace_root)))

    return {
        "workspace_root": str(workspace_root),
        "created": created,
        "config_path": str(config_path),
        "schema_path": str(schema_path),
        "codegraph_dir": str(codegraph_dir),
        "project_profile": config_payload.get("project_profile", AUTO_PROFILE),
        "project_root": config_payload["project_root"],
        "primary_adapter": config_payload["primary_adapter"],
        "supplemental_adapters": config_payload["supplemental_adapters"],
    }


def set_fixture_config(workspace_root: pathlib.Path, fixture: str, persist: bool) -> pathlib.Path:
    config_path = config_path_for(workspace_root)
    payload = load_json(config_path)
    payload["project_root"] = f"examples/{fixture}"
    payload["primary_adapter"] = "auto"
    payload["language_adapter"] = "auto"
    if persist:
        write_json(config_path, payload)
        return config_path
    temp_config_path = workspace_root / ".ai" / "codegraph" / f"demo-{fixture}-config.json"
    temp_config_path.parent.mkdir(parents=True, exist_ok=True)
    write_json(temp_config_path, payload)
    return temp_config_path


def apply_python_demo_edit(workspace_root: pathlib.Path) -> str:
    target = workspace_root / "examples" / "python_minimal" / "src" / "app.py"
    original = target.read_text(encoding="utf-8")
    if 'DEMO_RELEASE_TRACK = "baseline"' in original:
        updated = original.replace('DEMO_RELEASE_TRACK = "baseline"', 'DEMO_RELEASE_TRACK = "edited-by-demo"')
    elif 'DEMO_RELEASE_TRACK = "edited-by-demo"' in original:
        updated = original.replace('DEMO_RELEASE_TRACK = "edited-by-demo"', 'DEMO_RELEASE_TRACK = "baseline"')
    else:
        raise RuntimeError("Demo edit marker not found in python fixture")
    if updated == original:
        raise RuntimeError("Python demo edit did not change the file")
    target.write_text(updated, encoding="utf-8")
    return "src/app.py"


def apply_tsjs_demo_edit(workspace_root: pathlib.Path) -> str:
    target = workspace_root / "examples" / "tsjs_minimal" / "src" / "math.js"
    original = target.read_text(encoding="utf-8")
    if 'const DEMO_TSJS_TRACK = "baseline";' in original:
        updated = original.replace('const DEMO_TSJS_TRACK = "baseline";', 'const DEMO_TSJS_TRACK = "edited-by-demo";')
    elif 'const DEMO_TSJS_TRACK = "edited-by-demo";' in original:
        updated = original.replace('const DEMO_TSJS_TRACK = "edited-by-demo";', 'const DEMO_TSJS_TRACK = "baseline";')
    else:
        raise RuntimeError("Demo edit marker not found in tsjs fixture")
    if updated == original:
        raise RuntimeError("TS/JS demo edit did not change the file")
    target.write_text(updated, encoding="utf-8")
    return "src/math.js"


def apply_generic_demo_edit(workspace_root: pathlib.Path) -> str:
    target = workspace_root / "examples" / "generic_minimal" / "src" / "settings.conf"
    original = target.read_text(encoding="utf-8")
    if "release_track=baseline" in original:
        updated = original.replace("release_track=baseline", "release_track=edited-by-demo")
    elif "release_track=edited-by-demo" in original:
        updated = original.replace("release_track=edited-by-demo", "release_track=baseline")
    else:
        raise RuntimeError("Demo edit marker not found in generic fixture")
    if updated == original:
        raise RuntimeError("Generic demo edit did not change the file")
    target.write_text(updated, encoding="utf-8")
    return "src/settings.conf"


def _toggle_marker(target: pathlib.Path, baseline: str, edited: str, changed_file: str) -> str:
    original = target.read_text(encoding="utf-8")
    if baseline in original:
        updated = original.replace(baseline, edited)
    elif edited in original:
        updated = original.replace(edited, baseline)
    else:
        raise RuntimeError(f"Demo edit marker not found in {target}")
    if updated == original:
        raise RuntimeError(f"Demo edit did not change {target}")
    target.write_text(updated, encoding="utf-8")
    return changed_file


def apply_sql_pg_demo_edit(workspace_root: pathlib.Path) -> str:
    return _toggle_marker(
        workspace_root / "examples" / "sql_pg_minimal" / "db" / "functions" / "session.sql",
        "-- stage5 demo marker: baseline",
        "-- stage5 demo marker: edited",
        "db/functions/session.sql",
    )


def apply_tsjs_pg_demo_edit(workspace_root: pathlib.Path) -> str:
    return _toggle_marker(
        workspace_root / "examples" / "tsjs_pg_compound" / "src" / "sessionQueries.js",
        'const DEMO_COMPOUND_TRACK = "baseline";',
        'const DEMO_COMPOUND_TRACK = "edited";',
        "src/sessionQueries.js",
    )


def fixture_spec(fixture: str) -> dict:
    specs = {
        "python_minimal": {
            "task_id": "demo-login-impact",
            "seed": "fn:src/app.py:login",
            "edit": apply_python_demo_edit,
            "profile": "python-basic",
        },
        "tsjs_minimal": {
            "task_id": "demo-tsjs-impact",
            "seed": "fn:src/math.js:add",
            "edit": apply_tsjs_demo_edit,
            "profile": "node-cli",
        },
        "generic_minimal": {
            "task_id": "demo-generic-impact",
            "seed": "file:src/settings.conf",
            "edit": apply_generic_demo_edit,
            "profile": "generic-file",
        },
        "tsjs_node_cli": {
            "task_id": "demo-node-cli-impact",
            "seed": "fn:src/cli.js:runCommand",
            "edit": lambda root: _toggle_marker(root / "examples" / "tsjs_node_cli" / "src" / "cli.js", 'const DEMO_NODE_CLI_TRACK = "baseline";', 'const DEMO_NODE_CLI_TRACK = "edited-by-demo";', "src/cli.js"),
            "profile": "node-cli",
        },
        "tsx_react_vite": {
            "task_id": "demo-react-vite-impact",
            "seed": "fn:src/AppShell.tsx:AppShell",
            "edit": lambda root: _toggle_marker(root / "examples" / "tsx_react_vite" / "src" / "AppShell.tsx", 'const DEMO_REACT_VITE_TRACK = "baseline";', 'const DEMO_REACT_VITE_TRACK = "edited-by-demo";', "src/AppShell.tsx"),
            "profile": "react-vite",
        },
        "sql_pg_minimal": {
            "task_id": "demo-sql-pg-impact",
            "seed": "fn:db/functions/session.sql:app.issue_session_token",
            "edit": apply_sql_pg_demo_edit,
            "profile": "generic-file",
            "with_adapters": ["sql-postgres"],
        },
        "tsjs_pg_compound": {
            "task_id": "demo-tsjs-pg-impact",
            "seed": "fn:src/sessionQueries.js:fetchSessionLabel",
            "edit": apply_tsjs_pg_demo_edit,
            "profile": "node-cli",
            "with_adapters": ["sql-postgres"],
        },
    }
    if fixture not in specs:
        raise SystemExit(f"Unsupported fixture: {fixture}")
    return specs[fixture]


def detect_payload(workspace_root: pathlib.Path, config_path: pathlib.Path) -> dict:
    config = build_graph.load_config(config_path)
    project_root = build_graph.project_root_for(workspace_root, config)
    detected_adapter = detect_language_adapter(project_root, config)
    detected_profile, confidence, reason = detect_project_profile(project_root, config, detected_adapter)
    supplemental_detected = detect_supplemental_adapters(project_root, config)
    return {
        "workspace_root": str(workspace_root),
        "project_root": str(project_root),
        "primary_adapter": detected_adapter,
        "configured_adapter": config.get("language_adapter", "auto"),
        "configured_primary_adapter": config.get("primary_adapter", config.get("language_adapter", "auto")),
        "configured_profile": config.get("project_profile", AUTO_PROFILE),
        "detected_adapter": detected_adapter,
        "detected_profile": detected_profile,
        "configured_supplemental_adapters": configured_supplemental_adapters(config),
        "supplemental_adapters_detected": supplemental_detected,
        "confidence": confidence,
        "reason": reason,
    }


def command_available(command_name: str) -> bool:
    return shutil.which(command_name) is not None


def doctor_payload(workspace_root: pathlib.Path, config_path: pathlib.Path) -> dict:
    statuses: list[dict] = []
    overall = "PASS"

    def add_status(level: str, message: str) -> None:
        nonlocal overall
        statuses.append({"level": level, "message": message})
        if level == "FAIL":
            overall = "FAIL"
        elif level == "WARN" and overall != "FAIL":
            overall = "WARN"

    if config_path.exists():
        add_status("PASS", f"config {config_path.relative_to(workspace_root)}")
    else:
        add_status("FAIL", f"config missing at {config_path.relative_to(workspace_root)}")
        return {"overall": overall, "statuses": statuses}

    schema_path = schema_path_for(workspace_root)
    if schema_path.exists():
        add_status("PASS", f"schema {schema_path.relative_to(workspace_root)}")
    else:
        add_status("FAIL", f"schema missing at {schema_path.relative_to(workspace_root)}")
        return {"overall": overall, "statuses": statuses}

    config = build_graph.load_config(config_path)
    project_root = build_graph.project_root_for(workspace_root, config)
    if project_root.exists():
        add_status("PASS", f"project_root {project_root}")
    else:
        add_status("FAIL", f"project_root missing: {project_root}")
        return {"overall": overall, "statuses": statuses}

    try:
        detected_adapter = detect_language_adapter(project_root, config)
        detected_profile, confidence, reason = detect_project_profile(project_root, config, detected_adapter)
        supplemental_detected = detect_supplemental_adapters(project_root, config)
        add_status("PASS", f"detected_adapter {detected_adapter}")
        add_status("PASS", f"profile {detected_profile} ({reason}, confidence={confidence:.2f})")
        if configured_supplemental_adapters(config):
            add_status("PASS", f"supplemental configured: {', '.join(configured_supplemental_adapters(config))}")
        if supplemental_detected:
            add_status("PASS", f"supplemental detected: {', '.join(supplemental_detected)}")
    except Exception as exc:  # pragma: no cover - defensive
        add_status("FAIL", f"adapter detection failed: {exc}")
        return {"overall": overall, "statuses": statuses}

    git_available = command_available("git")
    if not git_available:
        add_status("WARN", "git command not found; evidence will use UNCOMMITTED markers")
    else:
        try:
            subprocess.run(["git", "rev-parse", "--is-inside-work-tree"], cwd=workspace_root, check=True, capture_output=True, text=True)
            add_status("PASS", "git repository available")
        except subprocess.CalledProcessError:
            add_status("PASS", "git repository not initialized yet; evidence will use UNCOMMITTED markers until first commit")

    if detected_adapter == "python":
        add_status("PASS", "python runtime available")
        if command_available("coverage"):
            add_status("PASS", "coverage.py command available")
        else:
            try:
                subprocess.run([sys.executable, "-m", "coverage", "--version"], check=True, capture_output=True, text=True)
                add_status("PASS", "coverage.py module available")
            except subprocess.CalledProcessError:
                add_status("WARN", "coverage.py not available; graph/report still work but coverage import will be unavailable")
    elif detected_adapter == "tsjs":
        if command_available("node"):
            add_status("PASS", "node runtime available")
        else:
            add_status("WARN", "node runtime not found; tsjs test execution will be unavailable")
        package_json = package_json_data(project_root)
        if package_json:
            add_status("PASS", "package.json found")
        else:
            add_status("WARN", "package.json missing; node-cli profile will fall back to direct node commands")
        if detected_profile == "react-vite":
            deps = set(package_json.get("dependencies", {}).keys()) | set(package_json.get("devDependencies", {}).keys())
            if "react" in deps and "vite" in deps:
                add_status("PASS", "react-vite markers found")
            else:
                add_status("WARN", "react-vite profile is selected but package.json is missing react or vite markers")
        elif detected_profile == "next-basic":
            if any((project_root / name).exists() for name in ("next.config.js", "next.config.mjs", "next.config.ts")):
                add_status("PASS", "next markers found")
            else:
                add_status("WARN", "next-basic profile is preset-only until this project adds Next markers")
        elif detected_profile == "electron-renderer":
            add_status("WARN", "electron-renderer profile is preset-only in stage4")
        elif detected_profile == "obsidian-plugin":
            add_status("WARN", "obsidian-plugin profile is preset-only in stage4")
        elif detected_profile == "tauri-frontend":
            add_status("WARN", "tauri-frontend profile is preset-only in stage4")
    else:
        add_status("PASS", "generic fallback available")

    if SQL_POSTGRES_ADAPTER in configured_supplemental_adapters(config):
        sql_config = config.get(SQL_POSTGRES_ADAPTER, {})
        source_patterns = sql_config.get("source_globs", [])
        test_patterns = sql_config.get("test_globs", [])
        source_files = sum(1 for path in project_root.rglob("*.sql") if any(pathlib.PurePosixPath(path.relative_to(project_root).as_posix()).match(pattern) for pattern in source_patterns))
        test_files = sum(1 for path in project_root.rglob("*.sql") if any(pathlib.PurePosixPath(path.relative_to(project_root).as_posix()).match(pattern) for pattern in test_patterns))
        add_status("PASS", f"sql_postgres enabled (source_files={source_files}, test_files={test_files})")

    doc_level, doc_message = doc_source_doctor_status(project_root, config)
    add_status(doc_level, doc_message)

    return {"overall": overall, "statuses": statuses}


def print_doctor(payload: dict) -> None:
    print(f"OVERALL {payload['overall']}")
    for status in payload["statuses"]:
        print(f"{status['level']} {status['message']}")


def run_demo(fixture: str, workspace: str | None) -> pathlib.Path:
    source_root = template_root()
    workspace_root = pathlib.Path(workspace).resolve() if workspace else source_root
    spec = fixture_spec(fixture)
    if workspace:
        copy_template(source_root, workspace_root)
        init_git_repo(workspace_root)
    init_workspace(
        workspace_root,
        profile=spec.get("profile"),
        project_root=f"examples/{fixture}",
        with_adapters=spec.get("with_adapters"),
    )
    config_path = set_fixture_config(workspace_root, fixture, persist=bool(workspace))
    build_graph.build_graph(workspace_root=workspace_root, config_path=config_path)
    generate_report.generate_report(
        workspace_root=workspace_root,
        config_path=config_path,
        task_id=spec["task_id"],
        seed=spec["seed"],
    )
    changed_file = spec["edit"](workspace_root)
    after_edit_update.after_edit_update(
        workspace_root=workspace_root,
        config_path=config_path,
        task_id=spec["task_id"],
        seed=spec["seed"],
        changed_files=[changed_file],
    )
    return workspace_root


def main() -> int:
    parser = argparse.ArgumentParser(description="Unified Code Impact Guardian entry point")
    subparsers = parser.add_subparsers(dest="command", required=True)

    init_parser = subparsers.add_parser("init", help="Bootstrap config, schema, and artifact directories")
    init_parser.add_argument("--workspace-root", default=".")
    init_parser.add_argument("--profile", default=None)
    init_parser.add_argument("--project-root", default=None)
    init_parser.add_argument("--with", dest="with_adapters", action="append", default=[])

    doctor_parser = subparsers.add_parser("doctor", help="Run a lightweight workspace health check")
    doctor_parser.add_argument("--workspace-root", default=".")
    doctor_parser.add_argument("--config", default=".code-impact-guardian/config.json")

    detect_parser = subparsers.add_parser("detect", help="Detect the active adapter")
    detect_parser.add_argument("--workspace-root", default=".")
    detect_parser.add_argument("--config", default=".code-impact-guardian/config.json")

    build_parser = subparsers.add_parser("build", help="Build or refresh the graph")
    build_parser.add_argument("--workspace-root", default=".")
    build_parser.add_argument("--config", default=".code-impact-guardian/config.json")

    seeds_parser = subparsers.add_parser("seeds", help="List current seeds")
    seeds_parser.add_argument("--workspace-root", default=".")
    seeds_parser.add_argument("--config", default=".code-impact-guardian/config.json")

    report_parser = subparsers.add_parser("report", help="Generate an impact report")
    report_parser.add_argument("--workspace-root", default=".")
    report_parser.add_argument("--config", default=".code-impact-guardian/config.json")
    report_parser.add_argument("--task-id", required=True)
    report_parser.add_argument("--seed", required=True)
    report_parser.add_argument("--max-depth", type=int, default=None)

    after_parser = subparsers.add_parser("after-edit", help="Refresh graph, report, evidence, and tests after an edit")
    after_parser.add_argument("--workspace-root", default=".")
    after_parser.add_argument("--config", default=".code-impact-guardian/config.json")
    after_parser.add_argument("--task-id", required=True)
    after_parser.add_argument("--seed", required=True)
    after_parser.add_argument("--changed-file", action="append", default=[])

    demo_parser = subparsers.add_parser("demo", help="Run a fixture end-to-end demo")
    demo_parser.add_argument("--fixture", choices=["python_minimal", "tsjs_minimal", "generic_minimal", "tsjs_node_cli", "tsx_react_vite", "sql_pg_minimal", "tsjs_pg_compound"], default="python_minimal")
    demo_parser.add_argument("--workspace", default=None)

    args = parser.parse_args()

    if args.command == "demo":
        workspace_root = run_demo(args.fixture, args.workspace)
        print(workspace_root)
        return 0

    workspace_root = pathlib.Path(args.workspace_root).resolve()

    if args.command == "init":
        print(
            json.dumps(
                init_workspace(
                    workspace_root,
                    profile=args.profile,
                    project_root=args.project_root,
                    with_adapters=args.with_adapters,
                ),
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0

    config_path = pathlib.Path(getattr(args, "config", ".code-impact-guardian/config.json"))
    if not config_path.is_absolute():
        config_path = (workspace_root / config_path).resolve()

    if args.command == "doctor":
        print_doctor(doctor_payload(workspace_root, config_path))
        return 0
    if args.command == "detect":
        print(json.dumps(detect_payload(workspace_root, config_path), ensure_ascii=False, indent=2))
        return 0
    if args.command == "build":
        print(json.dumps(build_graph.build_graph(workspace_root=workspace_root, config_path=config_path), ensure_ascii=False, indent=2))
        return 0
    if args.command == "seeds":
        print(json.dumps(list_seeds.list_seeds(workspace_root=workspace_root, config_path=config_path), ensure_ascii=False, indent=2))
        return 0
    if args.command == "report":
        print(
            json.dumps(
                generate_report.generate_report(
                    workspace_root=workspace_root,
                    config_path=config_path,
                    task_id=args.task_id,
                    seed=args.seed,
                    max_depth=args.max_depth,
                ),
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0
    if args.command == "after-edit":
        print(
            json.dumps(
                after_edit_update.after_edit_update(
                    workspace_root=workspace_root,
                    config_path=config_path,
                    task_id=args.task_id,
                    seed=args.seed,
                    changed_files=args.changed_file,
                ),
                ensure_ascii=False,
                indent=2,
            )
        )
        return 0
    raise SystemExit(f"Unknown command: {args.command}")


if __name__ == "__main__":
    raise SystemExit(main())
