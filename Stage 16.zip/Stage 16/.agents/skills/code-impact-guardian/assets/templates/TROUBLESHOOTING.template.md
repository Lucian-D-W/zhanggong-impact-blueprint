# Code Impact Guardian Troubleshooting

This file defines the recovery protocol for agents and humans.

## Doctor failed

1. Read `.ai/codegraph/logs/last-error.json`
2. If the error is config-related, run `setup` again with the right profile and project root.
3. If the error is supplemental-adapter-related, either add the expected files or remove that supplemental adapter from config.
4. Start with `health` for the compact readiness summary, then re-run `doctor`, or try `doctor --fix-safe` for safe repairs only

## Detect is uncertain

1. If `detect` falls back to `generic`, decide whether that is acceptable for this repo.
2. If the repo should be Python or TS/JS, set `--profile` or `primary_adapter` explicitly.
3. If the parser still cannot recognize the project, continue with generic fallback instead of fabricating function-level truth.
4. `analyze --allow-fallback` and `finish --allow-fallback` will continue in file-level mode when that is the safest choice.
5. Check `.ai/codegraph/context-resolution.json` to see which source the skill trusted for changed files and seed hints.

## Build failed

1. Check `last-error.json` and `errors.jsonl`
2. Confirm config exists and `project_root` is correct
3. Confirm parser-specific source globs match real files
4. Read `.ai/codegraph/build-decision.json` to see why the run wanted incremental vs full
5. If generated/cache files polluted the diff, ignore them or add them to `.gitignore` before retrying
6. Retry with `--debug` only if the structured error is not enough

## Build is locked

1. Run `python .agents/skills/code-impact-guardian/cig.py status --workspace-root .`
2. Confirm no other build is still running before touching `.ai/codegraph/build.lock`
3. Only then remove the stale lock file and retry
4. Do not delete the lock preemptively while another agent or process may still be building

## Report failed

1. Confirm the seed exists in `cig.py seeds`
2. Read `.ai/codegraph/seed-candidates.json` for the top ranked candidates
3. If the seed is too broad or stale, rerun `analyze` with `--changed-line <path:line>` or `--patch-file <path>`
4. If needed, start from a file seed before returning to a function/routine seed
5. If multiple candidates were found, use one of the top suggested seeds from the structured error
6. If the error is `CONTEXT_MISSING`, do not trust an empty-looking report; provide context first or explicitly allow fallback
7. If the task is documentation-only, use `classify-change` to decide whether a lightweight or bypass flow is the safer path instead of forcing a fake code seed

## After-edit test failed

1. Do not fabricate success
2. Keep `test-results.json` and the report as evidence
3. Read `handoff/latest.md`
4. Read `.ai/codegraph/last-task.json` to recover the last analyze context
5. Read `.ai/codegraph/next-action.json` for the most specific retry recommendation
6. Fix the test command or the code under test
7. Re-run `finish` or `after-edit`

## Contract context looks wrong

1. Read `.ai/codegraph/next-action.json`
2. Confirm the current task was not pulled toward a stale recent code seed
3. Inspect `affected_contracts` and `architecture_chains` when contract-level blast radius is part of the problem
4. If the task is documentation-only, do not overfit the edit to irrelevant runtime context

## Coverage unavailable

1. Record the unavailable status and reason
2. Continue the workflow without pretending coverage exists
3. If needed, fix the coverage adapter later as a separate task
4. Do not describe `coverage unavailable` or `tests passed` as proof of safety

## Supplemental adapter failed

1. If the primary adapter still works, continue with the primary graph and record the supplemental failure
2. If the supplemental adapter is required for the task, fix its paths/config first
3. For `sql_postgres`, high-confidence query hints may remain hints until SQL parsing is restored
4. Supplemental adapter failures should degrade to warnings whenever the primary graph is still usable

## Error code guide

- `CONFIG_MISSING`: run `init`
- `BUILD_LOCKED`: inspect status first and only remove `.ai/codegraph/build.lock` after confirming no active build is running
- `CONTEXT_MISSING`: pass `--changed-file`, pass `--patch-file`, initialize git, or use `--allow-fallback` only if file-level continuation is acceptable
- `INVALID_PROFILE`: choose a supported profile and run `init` again
- `SUPPLEMENTAL_ADAPTER_MISSING`: add the expected files or disable the supplemental adapter
- `SEED_SELECTION_REQUIRED`: rerun `analyze` or `report` with `--changed-line` or an explicit `--seed`
- `TASK_CONTEXT_MISSING`: rerun `analyze`, or provide `--seed` / `--task-id` explicitly when no recent context exists
- `TEST_COMMAND_FAILED`: inspect `test-results.json` and the command output log, then retry after fixing the command or failing code
- `UNEXPECTED_ERROR`: retry with `--debug` and inspect the latest error log
