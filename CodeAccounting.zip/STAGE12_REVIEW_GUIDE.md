# Stage 12 Review Guide

This bundle is meant for external review of the Code Impact Guardian template repository.

## What is included

- Core skill implementation under `.agents/skills/code-impact-guardian/`
- Repo-local configuration under `.code-impact-guardian/`
- Support scripts under `scripts/`
- Full workflow tests under `tests/`
- Example consumer fixtures under `examples/`
- Benchmark fixtures under `benchmark/`
- Root documentation in `README.md` and `AGENTS.md`

## What reviewers should check first

1. `tests/test_stage10_workflow.py`
2. `tests/test_stage11_workflow.py`
3. `.agents/skills/code-impact-guardian/scripts/build_graph.py`
4. `.agents/skills/code-impact-guardian/scripts/after_edit_update.py`
5. `.agents/skills/code-impact-guardian/scripts/trust_policy.py`
6. `.agents/skills/code-impact-guardian/cig.py`

## Suggested validation commands

```powershell
python -m unittest tests.test_stage10_workflow -v
python -m unittest tests.test_stage11_workflow -v
python -m unittest discover -s tests -v
```

## Packaging intent

The zip is supposed to be self-consistent and runnable for review:

- If `tests/` is present, all required fixtures are present too.
- `benchmark/` is intentionally included because Stage 9 workflow tests depend on it.
- Temporary runtime state such as `.ai/` and VCS metadata such as `.git/` are intentionally excluded.
