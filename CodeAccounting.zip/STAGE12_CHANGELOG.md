# Stage 12 Changelog

This note summarizes the main fixes and packaging updates included in the current Stage 12 review bundle.

## Product fixes

- Preserved trust downgrades during `--full-rebuild`
  - `force_full` still forces a full rebuild
  - but no longer overwrites `graph_trust` / `trust_level` back to `high`
  - covered by Stage 11 regressions for dependency fingerprint `changed` and `unknown`

- Preserved deleted files during context inference
  - delete-only working tree diffs no longer fall out of inferred context

- Hardened recovery command workspace targeting
  - recovery commands now stay bound to the intended workspace
  - quoting is safer for paths with spaces and shell-sensitive characters

- Improved real test-count parsing
  - mixed `error/errors` summaries no longer double-count
  - parser remains honest when test counts are unknown

- Improved self-hosting guard focus
  - repo-local config now targets the repository root for self-hosting
  - nested copied `dist/` trees no longer pollute source matching

## Bundle updates

- `benchmark/` is included so Stage 9 benchmark-driven tests can run in the review bundle
- `review 0419.txt` is included for reviewer context
- `STAGE12_REVIEW_GUIDE.md` is included as a quick orientation doc
- `AGENTS.md` now records the repository's review-bundle packaging rules
