# Impact Report

## Task
- task_id: demo-login-impact
- generated_at: 2026-04-17T14:44:32+00:00
- git_sha: UNCOMMITTED
- seed: fn:src/app.py:login

## Direct Impact
- owning file:
  - `file:src/app.py`
- direct upstream callers:
  - none
- direct downstream callees:
  - `fn:src/app.py:login` --CALLS--> `fn:src/app.py:validate_password`
  - `fn:src/app.py:login` --CALLS--> `fn:src/session.py:create_session`
- direct tests:
  - `test:tests/test_app.py:LoginFlowTest.test_login_creates_session`
  - `test:tests/test_app.py:LoginFlowTest.test_login_rejects_bad_credentials`
- direct rules:
  - `rule:auth-session-invariant`
- direct file imports:
  - `file:src/app.py` --IMPORTS--> `file:src/session.py`

## Transitive Impact
- max_depth: 3
- downstream CALLS paths:
  - `fn:src/app.py:login -> fn:src/app.py:validate_password`
  - `fn:src/app.py:login -> fn:src/session.py:create_session`
- upstream CALLS paths:
  - none
- IMPORTS paths from owning file:
  - `file:src/app.py -> file:src/session.py`

## Risks
- api_compatibility: low
- state_or_side_effects: high
- coverage_status: covered-by-direct-tests

## Evidence
- `file:src/app.py` --DEFINES--> `fn:src/app.py:login` from `src/app.py`:10-14 (git_sha=UNCOMMITTED, diff_ref=WORKTREE, blame_ref=None, extractor=python_ast)
- `fn:src/app.py:login` --CALLS--> `fn:src/app.py:validate_password` from `src/app.py`:11-11 (git_sha=UNCOMMITTED, diff_ref=WORKTREE, blame_ref=None, extractor=python_call_ast)
- `fn:src/app.py:login` --CALLS--> `fn:src/session.py:create_session` from `src/app.py`:13-13 (git_sha=UNCOMMITTED, diff_ref=WORKTREE, blame_ref=None, extractor=python_call_ast)
- `test:tests/test_app.py:LoginFlowTest.test_login_creates_session` --COVERS--> `fn:src/app.py:login` from `tests/test_app.py`:8-8 (git_sha=UNCOMMITTED, diff_ref=WORKTREE, blame_ref=None, extractor=python_test_ast)
- `test:tests/test_app.py:LoginFlowTest.test_login_rejects_bad_credentials` --COVERS--> `fn:src/app.py:login` from `tests/test_app.py`:13-13 (git_sha=UNCOMMITTED, diff_ref=WORKTREE, blame_ref=None, extractor=python_test_ast)
- `rule:auth-session-invariant` --GOVERNS--> `fn:src/app.py:login` from `docs/rules/auth-session.md`:1-11 (git_sha=UNCOMMITTED, diff_ref=WORKTREE, blame_ref=None, extractor=markdown_rule)
- `file:src/app.py` --IMPORTS--> `file:src/session.py` from `src/app.py`:1-1 (git_sha=UNCOMMITTED, diff_ref=WORKTREE, blame_ref=None, extractor=python_import_ast)

## Mermaid
```mermaid
flowchart LR
  "file:src/app.py" --> "fn:src/app.py:login"
  "fn:src/app.py:login" --> "fn:src/app.py:validate_password"
  "fn:src/app.py:login" --> "fn:src/session.py:create_session"
  "test:tests/test_app.py:LoginFlowTest.test_login_creates_session" --> "fn:src/app.py:login"
  "test:tests/test_app.py:LoginFlowTest.test_login_rejects_bad_credentials" --> "fn:src/app.py:login"
  "rule:auth-session-invariant" --> "fn:src/app.py:login"
  "file:src/app.py" --> "file:src/session.py"
```

## Post-change note
- pending

- updated_at: 2026-04-17T14:44:34+00:00
- changed_files: src/app.py
- graph_refresh: complete (11 nodes, 13 edges)
- tests: passed (exit_code=0)
- coverage_status: available
- coverage_reason: none
